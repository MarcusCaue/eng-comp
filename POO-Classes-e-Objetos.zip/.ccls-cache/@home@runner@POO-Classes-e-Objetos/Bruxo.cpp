#include "Bruxo.hpp"
#include <iostream>

using std::cout;
using std::endl;
using std::string;

Bruxo::Bruxo(string nome, string casa, string feitico) {
  this->nome = nome;
  this->feiticoPredileto = feitico;
  setCasa(casa);
}

string Bruxo::getNome() { return this->nome; }
void Bruxo::setNome(string nome) { this->nome = nome; }

string Bruxo::getCasa() { return this->casa; }
void Bruxo::setCasa(string casa) {}

string Bruxo::getFeitico() { return this->feiticoPredileto; }
void Bruxo::setFeitico(string feitico) { this->feiticoPredileto = feitico; }